function NotFound() {
  return <div>page doesn&apos;t exist</div>;
}

export default NotFound;
