function UnauthPage() {
  return <h1>You don&apos;t have access to view this page</h1>;
}

export default UnauthPage;
